import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nao-encontrada',
  templateUrl: './nao-encontrada.component.html',
  styleUrls: ['./nao-encontrada.component.css']
})
export class NaoEncontradaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
